# -*- coding: utf-8 -*-
"""Application paths and state JSON helpers for Myostoox."""
from __future__ import annotations

import os
import sys
import json
from typing import Any, Dict, List, Optional

APP_NAME = "Myostoox"
CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".config", APP_NAME)
SOCKET_FILE = os.path.join(CONFIG_DIR, "instance.sock")
LOCK_FILE = os.path.join(CONFIG_DIR, "instance.lock")
PLAYLIST_FILE = os.path.join(CONFIG_DIR, "playlist.json")
RECENT_FILE = os.path.join(CONFIG_DIR, "recent.json")
RECENT_MAX = 15
META_CACHE_FILE = os.path.join(CONFIG_DIR, "meta_cache.json")
META_DISK_MAX = 5000
STATE_FILE = os.path.join(CONFIG_DIR, "state.json")
RESUME_FILE = os.path.join(CONFIG_DIR, "resume.json")
RADIOS_FILE = os.path.join(CONFIG_DIR, "radios.json")
TVS_FILE = os.path.join(CONFIG_DIR, "tvs.json")
BOUQUETS_FILE = os.path.join(CONFIG_DIR, "bouquets.json")
EQ_PRESETS_FILE = os.path.join(CONFIG_DIR, "eq_presets.json")
ASSOCIATIONS_FILE = os.path.join(CONFIG_DIR, "associations.json")
DESKTOP_FILE_NAME = f"{APP_NAME.lower()}.desktop"
DESKTOP_FILE_PATH = os.path.join(
    os.path.expanduser("~"),
    ".local",
    "share",
    "applications",
    DESKTOP_FILE_NAME,
)
AUTOSTART_DIR = os.path.join(os.path.expanduser("~"), ".config", "autostart")
AUTOSTART_DESKTOP_PATH = os.path.join(AUTOSTART_DIR, DESKTOP_FILE_NAME)

WINDOW_PLACEMENTS = (
    "center",
    "top-left",
    "top-right",
    "bottom-left",
    "bottom-right",
)
WINDOW_PLACEMENT_MARGIN = 48

RESUME_MIN_POS_S = 30.0
RESUME_END_MARGIN_S = 30.0
RESUME_MAX_ENTRIES = 200
RESUME_SAVE_INTERVAL_S = 12.0
RESUME_SEEK_MAX_TRIES = 10

def ensure_config_dir() -> str:
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
    except Exception as exc:
        print("config dir:", exc, file=sys.stderr)
    return CONFIG_DIR

def atomic_write_json(path: str, data: Any) -> None:
    try:
        directory = os.path.dirname(path)
        if directory:
            os.makedirs(directory, exist_ok=True)
        temporary = path + ".tmp"
        with open(temporary, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(temporary, path)
    except Exception as exc:
        print("Écriture impossible :", path, exc, file=sys.stderr)

def load_json_dict(path: str) -> Optional[Dict[str, Any]]:
    if not os.path.isfile(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except Exception as e:
        print("Lecture JSON impossible :", path, e, file=sys.stderr)
    return None

def load_json_list(path: str) -> List[Any]:
    if not os.path.isfile(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            return data
    except Exception as e:
        print("Lecture JSON impossible :", path, e, file=sys.stderr)
    return []

def load_state(path: str = STATE_FILE) -> Optional[Dict[str, Any]]:
    return load_json_dict(path)

def save_state_dict(state: Dict[str, Any], path: str = STATE_FILE) -> None:
    ensure_config_dir()
    atomic_write_json(path, state)
