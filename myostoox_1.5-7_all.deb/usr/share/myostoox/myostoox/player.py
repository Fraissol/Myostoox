# -*- coding: utf-8 -*-
"""GStreamer engine helpers for Myostoox (app = window host)."""
from __future__ import annotations

import os
import re
import sys

DEBUG_MYOSTOOX = bool(os.environ.get("MYOSTOOX_DEBUG", "").strip())


def zero_copy_enabled():
    """Opt-in GL/native path closer to zero-copy (default: off = 1.5.2 behaviour)."""
    v = os.environ.get("MYOSTOOX_ZERO_COPY", "").strip().lower()
    return v in ("1", "true", "yes", "on")


def _sink_factory_name(sink):
    try:
        fac = sink.get_factory() if sink is not None else None
        return ((fac.get_name() if fac is not None else "") or "").lower()
    except Exception:
        return ""


try:
    import gi
    gi.require_version("Gst", "1.0")
    from gi.repository import Gst
except Exception:
    Gst = None

try:
    from gi.repository import GLib
except Exception:
    GLib = None

try:
    gi.require_version("GstVideo", "1.0")
    from gi.repository import GstVideo
except Exception:
    GstVideo = None

try:
    from myostoox.playlist import is_stream, is_cdda, is_dvd, is_bluray, is_special_source
except Exception:
    try:
        from playlist import is_stream, is_cdda, is_dvd, is_bluray, is_special_source
    except Exception:
        def is_stream(path):
            return isinstance(path, str) and path.lower().startswith(
                ("http://", "https://", "mms://", "rtsp://", "icy://")
            )
        def is_cdda(path):
            return isinstance(path, str) and path.startswith("cdda://")
        def is_dvd(path):
            return isinstance(path, str) and path.lower().startswith("dvd://")
        def is_bluray(path):
            if not isinstance(path, str):
                return False
            p = path.lower()
            return p.startswith("bluray://") or p.startswith("bd://")
        def is_special_source(path):
            return is_cdda(path) or is_stream(path) or is_dvd(path) or is_bluray(path)

try:
    from myostoox.metadata import SUBTITLE_FONT_DESC
except Exception:
    try:
        from metadata import SUBTITLE_FONT_DESC
    except Exception:
        SUBTITLE_FONT_DESC = "DejaVu Sans Bold 12"


_ASS_OVERRIDE_RE = re.compile(r"\{\\[^{}]*\}|\{an\d\}")


def strip_ass_override_tags(text):
    if not text or "{" not in text:
        return text
    return _ASS_OVERRIDE_RE.sub("", text)


def _ass_tag_strip_probe(pad, info, *_args):
    try:
        buf = info.get_buffer()
        if buf is None:
            return Gst.PadProbeReturn.OK
        ok, mapinfo = buf.map(Gst.MapFlags.READ)
        if not ok:
            return Gst.PadProbeReturn.OK
        try:
            raw = bytes(mapinfo.data)
        finally:
            buf.unmap(mapinfo)
        if b"{" not in raw:
            return Gst.PadProbeReturn.OK
        text = raw.decode("utf-8", errors="replace")
        cleaned = strip_ass_override_tags(text)
        if cleaned == text:
            return Gst.PadProbeReturn.OK
        if not cleaned.strip("\x00 \t\r\n"):
            cleaned = " "  # texte vide après nettoyage : on garde un buffer valide
        newbuf = Gst.Buffer.new_wrapped(cleaned.encode("utf-8"))
        newbuf.pts = buf.pts
        newbuf.dts = buf.dts
        newbuf.duration = buf.duration
        newbuf.offset = buf.offset
        newbuf.offset_end = buf.offset_end
        pad.chain(newbuf)
        return Gst.PadProbeReturn.HANDLED
    except Exception as e:
        if DEBUG_MYOSTOOX:
            print("ass tag probe:", e, file=sys.stderr)
        return Gst.PadProbeReturn.OK


def attach_ass_tag_stripper(element):
    if Gst is None or element is None:
        return False
    try:
        pad = element.get_static_pad("text_sink")
        if pad is None:
            return False
        pad.add_probe(Gst.PadProbeType.BUFFER, _ass_tag_strip_probe)
        if DEBUG_MYOSTOOX:
            print("Myostoox: nettoyage balises ASS actif", file=sys.stderr)
        return True
    except Exception as e:
        print("attach_ass_tag_stripper:", e, file=sys.stderr)
        return False

_AV1_HW_OTHER_NAMES = (
    "vaav1dec",
    "vaapiav1dec",
    "v4l2av1dec",
    "msdkav1dec",
)
_AV1_HW_NVIDIA_NAMES = (
    "nvav1dec",
)
_AV1_HW_DECODER_NAMES = _AV1_HW_OTHER_NAMES + _AV1_HW_NVIDIA_NAMES
_AV1_SOFT_DECODER_ORDER = ("dav1ddec", "av1dec", "avdec_av1")
_NVIDIA_DECODER_NAMES = (
    "nvh264dec",
    "nvh265dec",
    "nvav1dec",
    "nvvp8dec",
    "nvvp9dec",
    "nvmpeg2videodec",
    "nvmpeg4videodec",
    "nvmpegvideodec",
    "nvv4l2decoder",
    "nvdec",
)
_OTHER_HW_DECODER_NAMES = (
    "vah264dec",
    "vah265dec",
    "vaav1dec",
    "vavp8dec",
    "vavp9dec",
    "vampeg2dec",
    "vaapidecodebin",
    "vaapih264dec",
    "vaapih265dec",
    "vaapiav1dec",
    "vaapivp8dec",
    "vaapivp9dec",
    "vulkanh264dec",
    "vulkanh265dec",
    "qsvh264dec",
    "qsvh265dec",
    "qsvvp9dec",
    "v4l2h265dec",
    "v4l2h264dec",
    "v4l2slh265dec",
    "v4l2slh264dec",
)
_SOFTWARE_VIDEO_DECODER_NAMES = (
    "avdec_h264",
    "avdec_h265",
    "avdec_hevc",
    "avdec_vp9",
    "avdec_vp8",
    "avdec_av1",
    "avdec_mpeg2video",
    "avdec_mpeg4",
    "dav1ddec",
    "av1dec",
)

def _gst_set_rank(name, rank):
    try:
        factory = Gst.ElementFactory.find(name)
        if factory is not None:
            factory.set_rank(rank)
    except Exception: pass


def gst_set_rank(name, rank):
    return _gst_set_rank(name, rank)

def apply_safe_gstreamer_ranks(prefer_nvidia_av1=False):
    _gst_set_rank("a52dec", Gst.Rank.NONE)
    for n in ("avdec_eac3", "avdec_ac3"):
        _gst_set_rank(n, Gst.Rank.PRIMARY + 100)
    for n in _AV1_HW_OTHER_NAMES:
        _gst_set_rank(n, Gst.Rank.NONE)
    if prefer_nvidia_av1:
        for n in _AV1_HW_NVIDIA_NAMES:
            _gst_set_rank(n, Gst.Rank.PRIMARY + 200)
        soft_ranks = (
            (_AV1_SOFT_DECODER_ORDER[0], Gst.Rank.PRIMARY + 90),
            (_AV1_SOFT_DECODER_ORDER[1], Gst.Rank.PRIMARY + 80),
            (_AV1_SOFT_DECODER_ORDER[2], Gst.Rank.PRIMARY + 70),
            ("av1parse", Gst.Rank.PRIMARY + 50),
        )
    else:
        for n in _AV1_HW_NVIDIA_NAMES:
            _gst_set_rank(n, Gst.Rank.NONE)
        soft_ranks = (
            (_AV1_SOFT_DECODER_ORDER[0], Gst.Rank.PRIMARY + 120),
            (_AV1_SOFT_DECODER_ORDER[1], Gst.Rank.PRIMARY + 110),
            (_AV1_SOFT_DECODER_ORDER[2], Gst.Rank.PRIMARY + 100),
            ("av1parse", Gst.Rank.PRIMARY + 50),
        )
    for n, rank in soft_ranks:
        _gst_set_rank(n, rank)


def hdr_tonemap_mode():
    """MYOSTOOX_HDR_TONEMAP : auto (défaut) | off / 0 | force (test)."""
    v = os.environ.get("MYOSTOOX_HDR_TONEMAP", "auto").strip().lower()
    if v in ("0", "false", "no", "off"):
        return "off"
    if v == "force":
        return "force"
    return "auto"


def _hdr_gl_elements_available():
    if Gst is None:
        return False
    for name in ("glupload", "glcolorconvert", "glshader", "glimagesink"):
        try:
            if Gst.ElementFactory.find(name) is None:
                return False
        except Exception:
            return False
    return True


def hdr_tonemap_wanted(app):
    """True si la vidéo courante doit passer par le tone mapping HDR10 → SDR."""
    if not getattr(app, "hdr_tonemap_enabled", True):
        return False
    mode = hdr_tonemap_mode()
    if mode == "off":
        return False
    path = getattr(app, "current_path", None)
    if not path:
        return False
    # La colorimétrie utilisateur (video-filter 8 bits) est incompatible
    if getattr(app, "colorimetry_enabled", False):
        return False
    # Échec précédent sur ce fichier → on reste sur l'ancien comportement
    if path == getattr(app, "_hdr_off_path", None):
        return False
    if mode != "force" and not getattr(app, "_current_video_hdr", False):
        return False
    return _hdr_gl_elements_available()


_HDR_TONEMAP_GLSL = """#version 100
#ifdef GL_ES
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
#endif
varying vec2 v_texcoord;
uniform sampler2D tex;

const float KNEE = 0.70;

vec3 pq_eotf(vec3 e) {
    const float m1 = 0.1593017578125;
    const float m2 = 78.84375;
    const float c1 = 0.8359375;
    const float c2 = 18.8515625;
    const float c3 = 18.6875;
    vec3 p = pow(clamp(e, 0.0, 1.0), vec3(1.0 / m2));
    vec3 num = max(p - vec3(c1), vec3(0.0));
    vec3 den = vec3(c2) - vec3(c3) * p;
    return pow(num / den, vec3(1.0 / m1));
}

float tonemap(float x) {
    float s = max(x - KNEE, 0.0) / (1.0 - KNEE);
    return min(x, KNEE) + (1.0 - KNEE) * s / (1.0 + s);
}

vec3 srgb_oetf(vec3 c) {
    c = clamp(c, 0.0, 1.0);
    vec3 lo = c * 12.92;
    vec3 hi = 1.055 * pow(max(c, vec3(0.0031308)), vec3(1.0 / 2.4)) - vec3(0.055);
    return mix(lo, hi, step(vec3(0.0031308), c));
}

void main() {
    vec4 t = texture2D(tex, v_texcoord);
    vec3 lin = pq_eotf(t.rgb) * (10000.0 / @WHITE@);
    float m = max(max(lin.r, lin.g), max(lin.b, 0.000001));
    lin *= tonemap(m) / m;
    mat3 bt2020_to_709 = mat3(
         1.6605, -0.1246, -0.0182,
        -0.5876,  1.1329, -0.1006,
        -0.0728, -0.0083,  1.1187);
    lin = bt2020_to_709 * lin;
    gl_FragColor = vec4(srgb_oetf(lin), t.a);
}
"""


def _hdr_tonemap_fragment():
    try:
        white = float(os.environ.get("MYOSTOOX_HDR_WHITE", "150").strip() or "150")
    except Exception:
        white = 150.0
    white = max(50.0, min(400.0, white))
    return _HDR_TONEMAP_GLSL.replace("@WHITE@", "%.1f" % white)


def _make_hdr_tonemap_chain():
    """[glupload, glcolorconvert, glshader] ou None si indisponible."""
    if Gst is None:
        return None
    try:
        upload = Gst.ElementFactory.make("glupload", "hdr-glupload")
        conv = Gst.ElementFactory.make("glcolorconvert", "hdr-glconv")
        shader = Gst.ElementFactory.make("glshader", "hdr-tonemap")
        if upload is None or conv is None or shader is None:
            return None
        shader.set_property("fragment", _hdr_tonemap_fragment())
        return [upload, conv, shader]
    except Exception as e:
        if DEBUG_MYOSTOOX:
            print("hdr tonemap chain:", e, file=sys.stderr)
        return None


def create_playbin(name="playbin"):
    if Gst is None:
        return None
    try:
        return Gst.ElementFactory.make("playbin", name)
    except Exception:
        return None

def _effective_perf_mode(app):
    cur = getattr(app, "current_path", None)
    if cur and cur == getattr(app, "_hw_fallback_path", None):
        return "software"
    return getattr(app, "performance_mode", "hardware")

def _should_use_custom_pipeline(app, path):
    if not isinstance(path, str): return False
    if is_stream(path) or is_cdda(path) or is_dvd(path) or is_bluray(path): return False
    if not os.path.isfile(path): return False
    if os.path.splitext(path)[1].lower() not in (".mkv", ".webm", ".mka"): return False
    # Custom path only for AC3/E-AC3 or AV1 (other multi-audio → playbin)
    if app._mkv_has_ac3_family_audio(path): return True
    if app._mkv_has_av1_video(path): return True
    return False


def _tune_playbin_element(app, element):
    """Best-effort tuning when playbin creates decoders/converters (4K)."""
    if element is None:
        return
    try:
        fac = element.get_factory()
        name = (fac.get_name() if fac is not None else "") or ""
    except Exception:
        return
    name_l = name.lower()
    if name_l == "textoverlay":
        attach_ass_tag_stripper(element)
        return
    try:
        ncpu = max(2, min(8, (os.cpu_count() or 2)))
    except Exception:
        ncpu = 4
    if (
        name_l.startswith("avdec_")
        or name_l in ("dav1ddec", "libvpxdec", "vpxdec", "vp9dec", "vp8dec")
    ):
        for prop in ("max-threads", "n-threads", "threads"):
            try:
                if element.find_property(prop):
                    element.set_property(prop, ncpu)
                    break
            except Exception:
                continue
        for prop, val in (
            ("frame-threads", max(1, ncpu // 2)),
            ("tile-threads", max(1, min(4, ncpu // 2))),
        ):
            try:
                if element.find_property(prop):
                    element.set_property(prop, val)
            except Exception:
                pass
        return
    if name_l == "videoconvert":
        try:
            if element.find_property("n-threads"):
                element.set_property("n-threads", max(1, min(6, ncpu)))
        except Exception:
            pass
        try:
            if element.find_property("dither"):
                element.set_property("dither", 0)
        except Exception:
            pass
        return
    if name_l in ("glimagesink", "ximagesink", "xvimagesink", "autovideosink"):
        soft = getattr(app, "performance_mode", "hardware") == "software"
        try:
            element.set_property("max-lateness", int((3 if soft else 2) * Gst.SECOND))
        except Exception:
            pass
        try:
            element.set_property("qos", True)
        except Exception:
            pass
        try:
            if element.find_property("processing-deadline") is not None:
                element.set_property(
                    "processing-deadline",
                    int((200 if soft else 120) * Gst.MSECOND),
                )
        except Exception:
            pass


def _on_playbin_deep_element_added(app, bin, sub_bin, element):
    try:
        _tune_playbin_element(app, element)
    except Exception:
        pass


def _apply_av_sync_compensation(app, enable=True):
    """Reset optional A/V offset (fixed delay disabled)."""
    try:
        player = getattr(app, "player", None)
        if player is not None and getattr(app, "_custom_pipeline", None) is None:
            if player.find_property("av-offset") is not None:
                player.set_property("av-offset", 0)
    except Exception:
        pass
    try:
        asink = getattr(app, "_custom_audio_sink", None)
        if asink is not None and asink.find_property("ts-offset") is not None:
            asink.set_property("ts-offset", 0)
    except Exception:
        pass
    try:
        app._av_audio_delay_ns = 0
    except Exception:
        pass


def _configure_playbin_buffers(app, audio_only=False):
    if app.player is None:
        return
    soft = getattr(app, "performance_mode", "hardware") == "software"
    if audio_only:
        buf_size = 2 * 1024 * 1024
        buf_dur = 2 * Gst.SECOND
    else:
        buf_size = (32 if soft else 24) * 1024 * 1024
        buf_dur = (8 if soft else 6) * Gst.SECOND
    for prop, value in (
        ("buffer-size", buf_size),
        ("buffer-duration", buf_dur),
    ):
        try:
            app.player.set_property(prop, value)
        except Exception:
            pass
    try:
        flags = int(app.player.get_property("flags"))
        VIDEO = 1 << 0
        AUDIO = 1 << 1
        TEXT = 1 << 2
        VIS = 1 << 3
        DOWNLOAD = 1 << 7
        NATIVE_VIDEO = 1 << 6
        DEINTERLACE = 1 << 9
        SOFT_COLORBALANCE = 1 << 10
        if audio_only:
            flags = (flags | AUDIO) & ~VIDEO & ~VIS & ~DOWNLOAD
        else:
            flags = (flags | VIDEO | AUDIO | TEXT) & ~VIS & ~DOWNLOAD
            if hdr_tonemap_wanted(app):
                if not getattr(app, "subtitles_enabled", True):
                    flags |= NATIVE_VIDEO
                flags &= ~(DEINTERLACE | SOFT_COLORBALANCE)
                app._hdr_flags_applied = True
            else:
                if getattr(app, "_hdr_flags_applied", False):
                    flags |= (DEINTERLACE | SOFT_COLORBALANCE)
                    app._hdr_flags_applied = False
                if zero_copy_enabled() and not soft:
                    sink = getattr(app, "video_sink", None) or getattr(
                        app, "_video_sink_overlay", None
                    )
                    sname = _sink_factory_name(sink)
                    if "gl" in sname:
                        flags |= NATIVE_VIDEO
                        flags &= ~(DEINTERLACE | SOFT_COLORBALANCE)
                        if DEBUG_MYOSTOOX:
                            print(
                                "[zero-copy] playbin NATIVE_VIDEO + lean filters",
                                file=sys.stderr,
                            )
                    else:
                        flags &= ~NATIVE_VIDEO
                else:
                    flags &= ~NATIVE_VIDEO
        app.player.set_property("flags", flags)
    except Exception:
        pass

def _active_pipeline(app):
    if app._custom_pipeline is not None: return app._custom_pipeline
    return app.player

def _detach_equalizer_for_custom(app):
    eq = getattr(app, "equalizer", None)
    if eq is None: return None
    try:
        parent = eq.get_parent()
        if parent is not None:
            try: eq.set_state(Gst.State.NULL)
            except Exception: pass
            parent.remove(eq)
    except Exception as e:
        print("detach equalizer:", e, file=sys.stderr)
        return None
    app._need_playbin_rebind = True
    return eq

def _destroy_custom_pipeline(app):
    pipe = app._custom_pipeline
    if pipe is None: return
    try:
        bus = pipe.get_bus()
        for hid in getattr(app, "_custom_bus_handler_ids", []) or []:
            try: bus.disconnect(hid)
            except Exception: pass
        try: bus.remove_signal_watch()
        except Exception: pass
    except Exception: pass
    app._custom_bus_handler_ids = []
    try:
        pipe.set_state(Gst.State.NULL)
        pipe.get_state(100 * Gst.MSECOND)
    except Exception: pass
    for el in (getattr(app, "spectrum", None), getattr(app, "equalizer", None)):
        if el is None: continue
        try:
            parent = el.get_parent()
            if parent is not None:
                try: el.set_state(Gst.State.NULL)
                except Exception: pass
                parent.remove(el)
        except Exception: pass
    app._custom_pipeline = None
    app._custom_volume = None
    app._custom_audio_sink = None
    app._custom_audio_linked = False
    app._custom_video_linked = False
    app._custom_sub_linked = False
    app._custom_audio_pads = []
    app._custom_audio_queue = None
    app._custom_audio_index = 0
    app._custom_subtitle_pads = []
    app._custom_subtitle_index = -1
    app._custom_sub_queue = None
    app._custom_sub_overlay = None
    app._custom_ext_sub_src = None
    app._custom_ext_sub_q = None
    app._custom_ext_sub_parse = None
    app._custom_sub_muted = False
    app._need_playbin_rebind = True
    try: app._mkv_probe_cache = {}
    except Exception: pass
    try:
        GLib.idle_add(_trim_memory_idle)
    except Exception:
        pass


def _trim_memory_idle():
    try:
        import gc
        gc.collect()
    except Exception:
        pass
    try:
        import ctypes
        ctypes.CDLL("libc.so.6").malloc_trim(0)
    except Exception:
        pass
    return False


def _configure_raw_video_sink(app, sink):
    """Apply presentation policy on the real sink element (not a bin)."""
    if sink is None:
        return
    soft = getattr(app, "performance_mode", "hardware") == "software"
    lateness = int((3 if soft else 2) * Gst.SECOND)
    deadline = int((200 if soft else 120) * Gst.MSECOND)
    props = {
        "force-aspect-ratio": True,
        "sync": True,
        "handle-events": False,
        "draw-borders": False,
        "qos": True,
        "max-lateness": lateness,
    }
    for prop, value in props.items():
        try:
            sink.set_property(prop, value)
        except Exception:
            pass
    try:
        if sink.find_property("processing-deadline") is not None:
            sink.set_property("processing-deadline", deadline)
    except Exception:
        pass
    for prop, value in (
        ("force-aspect-ratio", True),
        ("show-preroll-frame", True),
        ("enable-last-sample", False),
    ):
        try:
            if sink.find_property(prop) is not None:
                sink.set_property(prop, value)
        except Exception:
            pass


def _should_downscale_for_display(app, half_res_flag=True):
    """True if sink should limit width (tall 4K). Env: MYOSTOOX_DISABLE_HALF_RES / FORCE."""
    if not half_res_flag:
        return False
    v = os.environ.get("MYOSTOOX_DISABLE_HALF_RES", "").strip().lower()
    if v in ("1", "true", "yes", "on"):
        return False
    if os.environ.get("MYOSTOOX_FORCE_HALF_RES", "").strip().lower() in (
        "1", "true", "yes", "on"
    ):
        return True
    dims = getattr(app, "_current_video_dims", None)
    try:
        if dims is not None and len(dims) >= 2:
            w = int(dims[0] or 0)
            h = int(dims[1] or 0)
            if h > 0 and w > 0 and h < 2000:
                return False
    except Exception:
        pass
    return True  # unknown dims or tall 4K


def _wrap_video_sink_with_jitter_queue(app, sink, half_res=True):
    """queue [! videoscale ! caps] [! glupload ! glcolorconvert ! glshader] ! sink.

    Stable: downscale first (max 1920) then HDR shader.
    NATIVE_VIDEO is not forced when subtitles are enabled.
    """
    if sink is None or Gst is None:
        return sink

    try:
        app._video_sink_has_scale = False
        app._video_sink_has_tonemap = False
        app._hdr_tonemap_active = False
    except Exception:
        pass

    try:
        q = Gst.ElementFactory.make("queue", "video-sink-q")
        if q is None:
            return sink
        q.set_property("max-size-buffers", 8)
        q.set_property("max-size-bytes", 0)
        q.set_property("max-size-time", 0)
        q.set_property("leaky", 0)

        chain = [q]
        want_hdr = (
            hdr_tonemap_wanted(app)
            and _sink_factory_name(sink) == "glimagesink"
            and _hdr_gl_elements_available()
        )
        need_scale = _should_downscale_for_display(app, half_res)

        if need_scale:
            scale = Gst.ElementFactory.make("videoscale", "video-videoscale")
            capsfilter = Gst.ElementFactory.make("capsfilter", "video-half-res-caps")
            if scale is not None and capsfilter is not None:
                try:
                    scale.set_property("add-borders", False)
                except Exception:
                    pass
                try:
                    if scale.find_property("gamma-decode") is not None:
                        scale.set_property("gamma-decode", False)
                except Exception:
                    pass
                capsfilter.set_property(
                    "caps", Gst.Caps.from_string("video/x-raw,width=(int)[1,1920]")
                )
                chain.extend([scale, capsfilter])
                try:
                    app._video_sink_has_scale = True
                except Exception:
                    pass

        if want_hdr:
            hdr_chain = _make_hdr_tonemap_chain()
            if hdr_chain:
                chain.extend(hdr_chain)
                try:
                    app._video_sink_has_tonemap = True
                    app._hdr_tonemap_active = True
                    if DEBUG_MYOSTOOX:
                        print(
                            "Myostoox: tone mapping HDR10 actif (après downscale)",
                            file=sys.stderr,
                        )
                except Exception:
                    pass

        chain.append(sink)

        b = Gst.Bin.new("video-sink-bin")
        for el in chain:
            if el is not None:
                b.add(el)

        for a, c in zip(chain, chain[1:]):
            if a is None or c is None or not a.link(c):
                print("[VIDEO] échec de liaison", file=sys.stderr)
                return sink

        pad = q.get_static_pad("sink")
        if pad is None:
            return sink
        gp = Gst.GhostPad.new("sink", pad)
        if gp is None or not b.add_pad(gp):
            return sink
        gp.set_active(True)

        app._video_sink_overlay = sink
        return b

    except Exception as e:
        print("video sink jitter queue:", e, file=sys.stderr)
        return sink



def _create_video_sink(app, half_res=True):
    candidates = (
        "glimagesink",     # ratio correct + perf, handle posé avant PLAYING
        "ximagesink",      # repli fiable
        "xvimagesink",     # dernier recours (bug connu avec GLAMOR)
        "autovideosink",
    )
    sink = None
    for name in candidates:
        try:
            element = Gst.ElementFactory.make(name, "videosink")
        except Exception:
            element = None
        if element is not None:
            sink = element
            break
    if sink is None:
        return None
    _configure_raw_video_sink(app, sink)
    try:
        app._video_sink_overlay = sink
    except Exception:
        pass
    try:
        n = int(os.environ.get("MYOSTOOX_VSINK_QUEUE", "8").strip() or "8")
    except Exception:
        n = 8
    if n <= 0:
        try:
            app._video_sink_has_scale = False
            app._video_sink_has_tonemap = False
            app._hdr_tonemap_active = False
        except Exception:
            pass
        return sink
    return _wrap_video_sink_with_jitter_queue(app, sink, half_res=half_res)

def _build_mkv_pipeline(app, filepath, force_software=False):
    pipe = Gst.Pipeline.new("mkv-local-pipeline")
    perf_mode = "software" if force_software else app._effective_perf_mode()
    filesrc = Gst.ElementFactory.make("filesrc", "mkv-src")
    demux = Gst.ElementFactory.make("matroskademux", "mkv-demux")
    if not filesrc or not demux: return None
    filesrc.set_property("location", os.path.abspath(filepath))
    pipe.add(filesrc)
    pipe.add(demux)
    if not filesrc.link(demux): return None
    app._custom_sub_lang_list = app._discover_subtitle_languages(filepath)
    try:
        app._custom_audio_label_list = app._discover_audio_track_labels(filepath)
    except Exception:
        app._custom_audio_label_list = []
    app._custom_audio_linked = False
    app._custom_video_linked = False
    app._custom_sub_linked = False
    app._custom_sub_wait_scheduled = False
    app._custom_volume = None
    app._custom_audio_pads = []
    app._custom_audio_queue = None
    app._custom_audio_index = 0
    app._custom_subtitle_pads = []
    app._custom_subtitle_index = -1
    app._custom_sub_muted = False
    app._custom_sub_queue = None
    app._custom_is_av1 = False
    custom_eq = app._detach_equalizer_for_custom()
    video_sink = app._create_video_sink()
    if video_sink is None:
        video_sink = Gst.ElementFactory.make("autovideosink", "mkv-vsink")
    app.video_sink = video_sink
    app._video_sink_is_real = video_sink is not None
    try:
        if video_sink is not None and video_sink.find_property("force-aspect-ratio"):
            video_sink.set_property("force-aspect-ratio", True)
    except Exception: pass
    _n_subs = (getattr(app, "_custom_sub_lang_list", None) or {}).get("__n__")
    # textoverlay only when subs are known (avoids sysmem convert on pure 4K)
    try:
        _n_subs_i = int(_n_subs) if _n_subs is not None else 0
    except Exception:
        _n_subs_i = 0
    need_overlay = (
        _n_subs_i > 0
        or bool(getattr(app, "external_subtitles", None))
        or bool(getattr(app, "_preferred_ext_sub_path", None))
    )
    sub_overlay = None
    app._custom_sub_overlay_is_text = True
    if need_overlay:
        sub_overlay = Gst.ElementFactory.make("textoverlay", "mkv-subov")
        if sub_overlay is None:
            sub_overlay = Gst.ElementFactory.make("subtitleoverlay", "mkv-subov")
            app._custom_sub_overlay_is_text = False
    app._custom_sub_overlay = sub_overlay
    if sub_overlay is not None:
        pipe.add(sub_overlay)
        for prop, val in (
            ("shaded-background", False),
            ("draw-shadow", True),
            ("draw-outline", True),
            ("font-desc", SUBTITLE_FONT_DESC),
            ("valignment", 1),
            ("halignment", 1),
            ("line-alignment", 1),
            ("silent", True),
            ("wait-text", False),
            ("deltay", -12),
        ):
            try: sub_overlay.set_property(prop, val)
            except Exception: pass
        for prop, val in (
            ("valignment", "bottom"),
            ("halignment", "center"),
            ("font-desc", SUBTITLE_FONT_DESC),
        ):
            try: sub_overlay.set_property(prop, val)
            except Exception: pass
        try:
            sub_overlay.set_property("outline-color", 0xFF000000)
            sub_overlay.set_property("color", 0xFFFFFFFF)
        except Exception: pass
        if getattr(app, "_custom_sub_overlay_is_text", True):
            attach_ass_tag_stripper(sub_overlay)
    def _tune_queue(q, is_video=False, for_av1=False, for_eac3=False):
        if q is None: return
        try:
            soft = perf_mode == "software"
            if is_video:
                if for_av1:
                    max_buf = 120
                    max_bytes = 24 * 1024 * 1024
                    max_time = 2.0
                elif soft:
                    max_buf = 100
                    max_bytes = 16 * 1024 * 1024
                    max_time = 1.5
                else:
                    max_buf = 80
                    max_bytes = 12 * 1024 * 1024
                    max_time = 1.0
            else:
                if for_eac3 or for_av1:
                    max_buf = 200
                    max_bytes = 8 * 1024 * 1024
                    max_time = 3.0
                else:
                    max_buf = 100
                    max_bytes = 4 * 1024 * 1024
                    max_time = 2.0
            q.set_property("max-size-buffers", max_buf)
            q.set_property("max-size-bytes", max_bytes)
            q.set_property("max-size-time", int(max_time * Gst.SECOND))
            if is_video:
                try: q.set_property("leaky", 0)
                except Exception: pass
            elif for_eac3 or for_av1:
                try: q.set_property("leaky", 0)
                except Exception: pass
            else:
                try:
                    q.set_property("leaky", 2)
                except Exception:
                    try: q.set_property("leaky", True)
                    except Exception: pass
        except Exception: pass
    def _pad_language(pad, struct):
        if struct is not None:
            for key in ("language", "language-code", "lang"):
                try:
                    if struct.has_field(key):
                        ok, val = struct.get_string(key)
                        if ok and val and val not in ("und", "unk", ""): return val
                except Exception: pass
        try:
            event = pad.get_sticky_event(Gst.EventType.TAG, 0)
            if event is not None:
                tags = event.parse_tag()
                for tkey in (Gst.TAG_LANGUAGE_CODE, Gst.TAG_LANGUAGE_NAME):
                    try:
                        ok, val = tags.get_string(tkey)
                        if ok and val and val not in ("und", "unk", ""): return val
                    except Exception: pass
        except Exception: pass
        return None
    def _configure_software_decoder(decode):
        if decode is None: return
        try:
            ncpu = max(2, min(8, (os.cpu_count() or 2)))
            for prop in ("max-threads", "n-threads", "threads"):
                try:
                    if decode.find_property(prop):
                        decode.set_property(prop, ncpu)
                        break
                except Exception:
                    continue
            for prop, val in (
                ("frame-threads", max(1, ncpu // 2)),
                ("tile-threads", max(1, min(4, ncpu // 2))),
            ):
                try:
                    if decode.find_property(prop):
                        decode.set_property(prop, val)
                except Exception: pass
        except Exception: pass
    def _configure_videoconvert(convert):
        if convert is None: return
        try:
            if convert.find_property("n-threads"):
                convert.set_property(
                    "n-threads", max(1, min(6, (os.cpu_count() or 2)))
                )
        except Exception: pass
        try:
            if convert.find_property("dither"):
                convert.set_property("dither", 0)
        except Exception: pass
    def _sink_wants_gl():
        try:
            sink = video_sink
            if sink is None: return False
            fac = sink.get_factory()
            name = (fac.get_name() if fac is not None else "") or ""
            return "gl" in name.lower()
        except Exception:
            return False
    def _make_gl_convert_bin():
        try:
            upload = Gst.ElementFactory.make("glupload", "mkv-glupload")
            gconv = Gst.ElementFactory.make("glcolorconvert", "mkv-glcconv")
        except Exception:
            return None
        if upload is None or gconv is None: return None
        try:
            b = Gst.Bin.new("mkv-glconvert-bin")
            b.add(upload)
            b.add(gconv)
            if not upload.link(gconv): return None
            sinkpad = upload.get_static_pad("sink")
            srcpad = gconv.get_static_pad("src")
            if sinkpad is None or srcpad is None: return None
            gp_sink = Gst.GhostPad.new("sink", sinkpad)
            gp_src = Gst.GhostPad.new("src", srcpad)
            if gp_sink is None or gp_src is None: return None
            try:
                gp_sink.set_active(True)
                gp_src.set_active(True)
            except Exception: pass
            if not b.add_pad(gp_sink) or not b.add_pad(gp_src): return None
            return b
        except Exception as exc:
            if DEBUG_MYOSTOOX:
                print("gl convert bin:", exc, file=sys.stderr)
            return None
    def _make_video_convert_element(preferred=None):
        if preferred is not None:
            return preferred
        need_sysmem = bool(
            getattr(app, "_custom_sub_overlay", None) is not None
            or getattr(app, "colorimetry_enabled", False)
        )

        if zero_copy_enabled() and _sink_wants_gl() and not need_sysmem:
            if DEBUG_MYOSTOOX:
                print("Myostoox: MKV convert skipped (zero-copy)", file=sys.stderr)
            return None
        if _sink_wants_gl() and not need_sysmem:
            glbin = _make_gl_convert_bin()
            if glbin is not None:
                if DEBUG_MYOSTOOX:
                    print(
                        "Myostoox: MKV convert GL (glupload+glcolorconvert)",
                        file=sys.stderr,
                    )
                return glbin
        convert = Gst.ElementFactory.make("videoconvert", "mkv-vconv")
        _configure_videoconvert(convert)
        return convert
    def _make_h265_chain():
        parse = Gst.ElementFactory.make("h265parse", "mkv-h265parse")
        if parse is None: return None
        mode = perf_mode
        if mode == "hardware":
            for dec_name, post_name in (
                ("nvh265dec", None),
                ("nvv4l2decoder", None),
                ("vah265dec", "vapostproc"),
                ("vaapih265dec", "vaapipostproc"),
                ("vulkanh265dec", None),
                ("qsvh265dec", None),
                ("v4l2h265dec", None),
            ):
                decode = Gst.ElementFactory.make(dec_name, "mkv-vdec")
                if decode is None: continue
                convert = None
                if post_name:
                    convert = Gst.ElementFactory.make(post_name, "mkv-vpost")
                convert = _make_video_convert_element(preferred=convert)
                if convert is None: continue
                return parse, decode, convert, dec_name
        decode = Gst.ElementFactory.make("avdec_h265", "mkv-vdec")
        convert = _make_video_convert_element()
        if not decode or not convert: return None
        _configure_software_decoder(decode)
        return parse, decode, convert, "avdec_h265"
    def _make_h264_chain():
        parse = Gst.ElementFactory.make("h264parse", "mkv-h264parse")
        if parse is None: return None
        mode = perf_mode
        if mode == "hardware":
            for dec_name, post_name in (
                ("nvh264dec", None),
                ("nvv4l2decoder", None),
                ("vah264dec", "vapostproc"),
                ("vaapih264dec", "vaapipostproc"),
                ("vulkanh264dec", None),
                ("qsvh264dec", None),
                ("v4l2h264dec", None),
            ):
                decode = Gst.ElementFactory.make(dec_name, "mkv-vdec")
                if decode is None: continue
                convert = None
                if post_name:
                    convert = Gst.ElementFactory.make(post_name, "mkv-vpost")
                convert = _make_video_convert_element(preferred=convert)
                if convert is None: continue
                return parse, decode, convert, dec_name
        decode = Gst.ElementFactory.make("avdec_h264", "mkv-vdec")
        convert = _make_video_convert_element()
        if not decode or not convert: return None
        _configure_software_decoder(decode)
        return parse, decode, convert, "avdec_h264"
    def _make_av1_chain():
        parse = Gst.ElementFactory.make("av1parse", "mkv-av1parse")
        mode = perf_mode
        if mode == "hardware":
            for dec_name, post_name in (
                ("nvav1dec", None),
                ("vaav1dec", "vapostproc"),
                ("vaapiav1dec", "vaapipostproc"),
            ):
                decode = Gst.ElementFactory.make(dec_name, "mkv-vdec")
                if decode is None: continue
                convert = None
                if post_name:
                    convert = Gst.ElementFactory.make(post_name, "mkv-vpost")
                convert = _make_video_convert_element(preferred=convert)
                if convert is None: continue
                return parse, decode, convert, dec_name
        for dec_name in _AV1_SOFT_DECODER_ORDER:
            decode = Gst.ElementFactory.make(dec_name, "mkv-vdec")
            if decode is None: continue
            convert = _make_video_convert_element()
            if convert is None: continue
            _configure_software_decoder(decode)
            return parse, decode, convert, dec_name
        return None
    def _make_vp9_chain():
        parse = Gst.ElementFactory.make("vp9parse", "mkv-vp9parse")
        if perf_mode == "hardware":
            for dec_name, post_name in (
                ("nvvp9dec", None),
                ("vavp9dec", "vapostproc"),
                ("vaapivp9dec", "vaapipostproc"),
                ("qsvvp9dec", None),
            ):
                decode = Gst.ElementFactory.make(dec_name, "mkv-vdec")
                if decode is None: continue
                convert = None
                if post_name:
                    convert = Gst.ElementFactory.make(post_name, "mkv-vpost")
                convert = _make_video_convert_element(preferred=convert)
                if convert is None: continue
                return parse, decode, convert, dec_name
        decode = Gst.ElementFactory.make("avdec_vp9", "mkv-vdec")
        convert = _make_video_convert_element()
        if not decode or not convert: return None
        _configure_software_decoder(decode)
        return parse, decode, convert, "avdec_vp9"
    def _make_vp8_chain():
        parse = Gst.ElementFactory.make("vp8parse", "mkv-vp8parse")
        if perf_mode == "hardware":
            for dec_name, post_name in (
                ("nvvp8dec", None),
                ("vavp8dec", "vapostproc"),
                ("vaapivp8dec", "vaapipostproc"),
            ):
                decode = Gst.ElementFactory.make(dec_name, "mkv-vdec")
                if decode is None: continue
                convert = None
                if post_name:
                    convert = Gst.ElementFactory.make(post_name, "mkv-vpost")
                convert = _make_video_convert_element(preferred=convert)
                if convert is None: continue
                return parse, decode, convert, dec_name
        decode = Gst.ElementFactory.make("avdec_vp8", "mkv-vdec")
        convert = _make_video_convert_element()
        if not decode or not convert: return None
        _configure_software_decoder(decode)
        return parse, decode, convert, "avdec_vp8"
    def _make_mpeg2_chain():
        parse = Gst.ElementFactory.make("mpegvideoparse", "mkv-mpeg2parse")
        if perf_mode == "hardware":
            for dec_name, post_name in (
                ("nvmpeg2videodec", None),
                ("nvmpegvideodec", None),
                ("vampeg2dec", "vapostproc"),
            ):
                decode = Gst.ElementFactory.make(dec_name, "mkv-vdec")
                if decode is None: continue
                convert = None
                if post_name:
                    convert = Gst.ElementFactory.make(post_name, "mkv-vpost")
                convert = _make_video_convert_element(preferred=convert)
                if convert is None: continue
                return parse, decode, convert, dec_name
        decode = Gst.ElementFactory.make("avdec_mpeg2video", "mkv-vdec")
        convert = _make_video_convert_element()
        if not decode or not convert: return None
        _configure_software_decoder(decode)
        return parse, decode, convert, "avdec_mpeg2video"
    def on_pad_added(demux_el, pad):
        try:
            caps = pad.get_current_caps()
            if caps is None or caps.is_empty():
                caps = pad.query_caps(None)
            struct = (
                caps.get_structure(0) if caps and caps.get_size() > 0 else None
            )
            media = struct.get_name() if struct else ""
        except Exception:
            media = ""
        if media.startswith("video/") and not app._custom_video_linked:
            if video_sink is None: return
            if "png" in media or "image/" in media: return
            queue = Gst.ElementFactory.make("queue", "mkv-vqueue")
            if not queue: return
            media_l = (media or "").lower()
            is_h265 = "h265" in media_l or "hevc" in media_l
            is_h264 = "h264" in media_l or "avc" in media_l
            is_av1 = "av1" in media_l or "av01" in media_l
            is_vp9 = "vp9" in media_l
            is_vp8 = "vp8" in media_l
            is_mpeg2 = (
                "mpeg-2" in media_l
                or "mpeg2" in media_l
                or media_l in ("video/mpeg", "video/x-mpeg")
                or ("mpeg" in media_l and "mpeg4" not in media_l and "mpeg-4" not in media_l)
            )
            if is_av1:
                app._custom_is_av1 = True
            _tune_queue(queue, True, for_av1=(is_av1 or is_h265))
            if is_h265:
                chain = _make_h265_chain()
            elif is_h264:
                chain = _make_h264_chain()
            elif is_av1:
                chain = _make_av1_chain()
            elif is_vp9:
                chain = _make_vp9_chain()
            elif is_vp8:
                chain = _make_vp8_chain()
            elif is_mpeg2:
                chain = _make_mpeg2_chain()
            else:
                chain = None
            if chain is not None:
                parse, decode, convert, label = chain
                for el in (queue, parse, decode, convert):
                    if el is None: continue
                    pipe.add(el)
                    el.sync_state_with_parent()
                smooth_q = Gst.ElementFactory.make("queue", "mkv-vsmooth")
                if smooth_q is not None:
                    try:

                        smooth_q.set_property(
                            "max-size-buffers",
                            24 if (is_av1 or is_h265) else 10,
                        )
                        smooth_q.set_property("max-size-bytes", 0)
                        smooth_q.set_property("max-size-time", 0)
                        smooth_q.set_property("leaky", 0)
                    except Exception:
                        pass
                    pipe.add(smooth_q)
                    smooth_q.sync_state_with_parent()
                if (is_av1 or is_h265) and video_sink is not None:
                    for prop, val in (
                        ("max-lateness", int(2 * Gst.SECOND)),
                        ("qos", True),
                    ):
                        try:
                            video_sink.set_property(prop, val)
                        except Exception:
                            pass
                    try:
                        if video_sink.find_property("processing-deadline") is not None:
                            video_sink.set_property(
                                "processing-deadline",
                                int(120 * Gst.MSECOND),
                            )
                    except Exception:
                        pass
                if video_sink.get_parent() is None:
                    pipe.add(video_sink)
                    video_sink.sync_state_with_parent()
                try:
                    pad.link(queue.get_static_pad("sink"))
                except Exception:
                    return
                if parse is not None:
                    if not (queue.link(parse) and parse.link(decode)): return
                else:
                    if not queue.link(decode): return
                tail = convert if (convert is not None and decode.link(convert)) else decode
                if smooth_q is not None:
                    if tail.link(smooth_q):
                        tail = smooth_q
                if sub_overlay is not None:
                    if getattr(app, "_custom_sub_overlay_is_text", True):
                        if not tail.link(sub_overlay):
                            app._link_through_video_color(
                                pipe, tail, video_sink
                            )
                        else:
                            app._link_through_video_color(
                                pipe, sub_overlay, video_sink
                            )
                    else:
                        try:
                            vpad = sub_overlay.get_static_pad("video_sink")
                            if vpad is not None:
                                tail.get_static_pad("src").link(vpad)
                                app._link_through_video_color(
                                    pipe, sub_overlay, video_sink
                                )
                            else:
                                app._link_through_video_color(
                                    pipe, tail, video_sink
                                )
                        except Exception:
                            app._link_through_video_color(
                                pipe, tail, video_sink
                            )
                else:
                    app._link_through_video_color(pipe, tail, video_sink)
                app._custom_video_linked = True
                if DEBUG_MYOSTOOX:
                    print(
                    "Myostoox: MKV vidéo (%s)" % label, file=sys.stderr
                )
                try: GLib.idle_add(app._ensure_video_sink_geometry)
                except Exception: pass
                return
            decode = Gst.ElementFactory.make("decodebin", "mkv-vdecode")
            convert = _make_video_convert_element()
            if not decode or not convert: return
            for el in (queue, decode, convert):
                pipe.add(el)
                el.sync_state_with_parent()
            if video_sink.get_parent() is None:
                pipe.add(video_sink)
                video_sink.sync_state_with_parent()
            try:
                pad.link(queue.get_static_pad("sink"))
            except Exception:
                return
            queue.link(decode)
            def on_vpad(dbin, dpad):
                try:
                    sp = convert.get_static_pad("sink")
                    if sp and not sp.is_linked():
                        dpad.link(sp)
                        if sub_overlay is not None and getattr(
                            app, "_custom_sub_overlay_is_text", True
                        ):
                            if convert.link(sub_overlay):
                                app._link_through_video_color(
                                    pipe, sub_overlay, video_sink
                                )
                            else:
                                app._link_through_video_color(
                                    pipe, convert, video_sink
                                )
                        elif sub_overlay is not None:
                            try:
                                vpad = sub_overlay.get_static_pad("video_sink")
                                convert.get_static_pad("src").link(vpad)
                                app._link_through_video_color(
                                    pipe, sub_overlay, video_sink
                                )
                            except Exception:
                                app._link_through_video_color(
                                    pipe, convert, video_sink
                                )
                        else:
                            app._link_through_video_color(
                                pipe, convert, video_sink
                            )
                except Exception as e:
                    if DEBUG_MYOSTOOX:
                        print("mkv video:", e, file=sys.stderr)
            decode.connect("pad-added", on_vpad)
            app._custom_video_linked = True
            if DEBUG_MYOSTOOX:
                print("Myostoox: MKV vidéo (decodebin)", file=sys.stderr)
            try: GLib.idle_add(app._ensure_video_sink_geometry)
            except Exception: pass
            return
        if media.startswith("audio/"):
            idx = len(app._custom_audio_pads)
            lang = _pad_language(pad, struct)
            nice = None
            try:
                alist = getattr(app, "_custom_audio_label_list", None) or []
                if idx < len(alist) and alist[idx]:
                    nice = alist[idx]
            except Exception:
                nice = None
            if not nice:
                if lang:
                    nice = "%s — %s%d" % (
                        lang, app.tr("Piste "), idx + 1
                    )
                else:
                    nice = app.tr("Piste ") + str(idx + 1)
            elif lang and lang not in nice:
                nice = "%s — %s" % (lang, nice)
            app._custom_audio_pads.append((pad, nice, media or ""))
            app.audio_tracks = [
                (i, lab) for i, entry in enumerate(app._custom_audio_pads)
                for lab in (entry[1],)
            ]
            if app._custom_audio_linked: return
            try:
                pref = int(getattr(app, "_preferred_custom_audio_index", -1))
            except Exception:
                pref = -1
            try:
                n_known = len(getattr(app, "_custom_audio_label_list", None) or [])
            except Exception:
                n_known = 0
            if pref >= 0 and n_known > 0 and pref < max(n_known, idx + 1) and idx != pref:
                return
            queue = Gst.ElementFactory.make("queue", "mkv-aqueue")
            convert = Gst.ElementFactory.make("audioconvert", "mkv-aconv")
            acaps = Gst.ElementFactory.make("capsfilter", "mkv-acaps")
            if acaps is not None:
                try:
                    acaps.set_property(
                        "caps",
                        Gst.Caps.from_string(
                            "audio/x-raw,format=F32LE,channels=2,"
                            "layout=interleaved"
                        ),
                    )
                except Exception:
                    try:
                        acaps.set_property(
                            "caps",
                            Gst.Caps.from_string(
                                "audio/x-raw,format=S16LE,channels=2,"
                                "layout=interleaved"
                            ),
                        )
                    except Exception:
                        acaps = None
            resample = Gst.ElementFactory.make(
                "audioresample", "mkv-aresample"
            )
            tempo = Gst.ElementFactory.make("scaletempo", "mkv-atempo")
            if resample is not None:
                try: resample.set_property("quality", 8)
                except Exception: pass
            spec = None
            volume = Gst.ElementFactory.make("volume", "mkv-volume")
            sink = Gst.ElementFactory.make("pulsesink", "mkv-asink")
            if sink is None:
                sink = Gst.ElementFactory.make("autoaudiosink", "mkv-asink")
            decode = None
            alabel = None
            media_a = (media or "").lower()
            is_eac3 = "eac3" in media_a or "e-ac-3" in media_a
            is_ac3 = (not is_eac3) and ("ac3" in media_a)
            is_av1_pipe = bool(getattr(app, "_custom_is_av1", False))
            cands = ()
            if is_eac3:
                cands = ("avdec_eac3", "avdec_ac3")
            elif is_ac3:
                cands = ("avdec_ac3", "avdec_eac3")
            for n in cands:
                decode = Gst.ElementFactory.make(n, "mkv-adec")
                if decode is not None:
                    for prop_name in (
                        "drc-scale",
                        "drc_scale",
                        "drc",
                    ):
                        try:
                            decode.set_property(prop_name, 0.0)
                            break
                        except Exception:
                            continue
                    alabel = n
                    break
            use_dbin = False
            if decode is None:
                decode = Gst.ElementFactory.make("decodebin", "mkv-adecode")
                alabel = "decodebin"
                use_dbin = True
            if not queue or not decode or not convert or not sink: return
            _tune_queue(
                queue,
                False,
                for_av1=is_av1_pipe,
                for_eac3=is_eac3 or is_ac3,
            )
            app._custom_audio_queue = queue
            app._custom_volume_boost = (
                2.4 if is_eac3 else (1.6 if is_ac3 else 1.0)
            )
            if volume is not None:
                try:
                    vol = float(app.volume_scale.get_value())
                    boost = float(getattr(app, "_custom_volume_boost", 1.0) or 1.0)
                    gain = 0.0 if getattr(app, "is_muted", False) else min(
                        3.5, vol * boost
                    )
                    volume.set_property("volume", gain)
                except Exception: pass
                app._custom_volume = volume
            if is_eac3 or is_ac3 or is_av1_pipe:
                buf_props = (
                    ("buffer-time", 1000000),   # 1 s
                    ("latency-time", 50000),    # 50 ms
                    ("drift-tolerance", 50000),
                )
            else:
                buf_props = (
                    ("buffer-time", 400000),
                    ("latency-time", 20000),
                )
            for prop, val in buf_props:
                try: sink.set_property(prop, val)
                except Exception: pass
            try: sink.set_property("sync", True)
            except Exception: pass
            try:
                app._custom_audio_sink = sink
            except Exception:
                pass
            try:
                if (
                    0 != 0
                    and sink.find_property("ts-offset") is not None
                ):
                    sink.set_property("ts-offset", 0)
            except Exception:
                pass
            amplify = None
            if is_eac3 or is_ac3:
                amplify = Gst.ElementFactory.make(
                    "audioamplify", "mkv-aamp"
                )
                if amplify is not None:
                    try:
                        amplify.set_property("amplification", 2.0)
                    except Exception:
                        try: amplify.set_property("amplification", 1.8)
                        except Exception: pass
            eq_el = custom_eq
            try:
                if eq_el is not None and eq_el.get_parent() is not None:
                    eq_el = None
            except Exception:
                eq_el = None
            elems = [queue, decode, convert]
            if acaps is not None:
                elems.append(acaps)
            if tempo is not None:
                elems.append(tempo)
            if spec is not None:
                elems.append(spec)
            if eq_el is not None:
                elems.append(eq_el)
            elems.append(resample)
            if volume is not None:
                elems.append(volume)
            if amplify is not None:
                elems.append(amplify)
            elems.append(sink)
            for el in elems:
                if el is not None:
                    pipe.add(el)
                    el.sync_state_with_parent()
            try:
                pad.link(queue.get_static_pad("sink"))
            except Exception:
                return
            if not queue.link(decode): return
            def finish(from_el):
                prev = from_el
                if acaps is not None:
                    if prev.link(acaps):
                        prev = acaps
                if tempo is not None:
                    if prev.link(tempo):
                        prev = tempo
                if spec is not None:
                    if prev.link(spec):
                        prev = spec
                if eq_el is not None:
                    if prev.link(eq_el):
                        prev = eq_el
                if resample is not None and prev.link(resample):
                    prev = resample
                if volume is not None and prev.link(volume):
                    prev = volume
                if amplify is not None and prev.link(amplify):
                    prev = amplify
                prev.link(sink)
            if use_dbin:
                def on_apad(dbin, dpad):
                    try:
                        sp = convert.get_static_pad("sink")
                        if sp and not sp.is_linked():
                            dpad.link(sp)
                            finish(convert)
                    except Exception as e:
                        if DEBUG_MYOSTOOX:
                            print("mkv audio:", e, file=sys.stderr)
                decode.connect("pad-added", on_apad)
            else:
                if decode.link(convert):
                    finish(convert)
            app._custom_audio_linked = True
            app._custom_audio_index = idx
            app.current_audio_index = idx
            if DEBUG_MYOSTOOX:
                print("Myostoox: MKV audio (%s)" % alabel, file=sys.stderr)
            return
        media_l = (media or "").lower()
        is_bitmap_sub = any(
            tok in media_l
            for tok in (
                "pgs",
                "hdmv",
                "vobsub",
                "dvdsub",
                "subpicture",
                "x-dvd",
                "x-avi-subtitle",
                "image/",
            )
        )
        if not media_l:
            try:
                tmpl = pad.get_pad_template()
                if tmpl is not None:
                    tcaps = tmpl.get_caps()
                    if tcaps and not tcaps.is_empty():
                        tstruct = tcaps.get_structure(0)
                        if tstruct:
                            media_l = (tstruct.get_name() or "").lower()
            except Exception: pass
        is_text_sub = (not is_bitmap_sub) and (
            media_l.startswith("text/")
            or media_l.startswith("application/x-subrip")
            or media_l.startswith("application/x-ssa")
            or media_l.startswith("application/x-ass")
            or media_l.startswith("application/x-subtitle")
            or media_l.startswith("subtitle/")
            or media_l in (
                "application/x-subtitle",
                "application/x-subtitle-unknown",
            )
            or "subrip" in media_l
            or "ssa" in media_l
            or media_l.endswith("/x-ass")
            or media_l.endswith("/x-ssa")
            or media_l.endswith("/x-raw")
        )
        if not is_text_sub and not is_bitmap_sub:
            try:
                event = pad.get_sticky_event(Gst.EventType.TAG, 0)
                if event is not None:
                    tags = event.parse_tag()
                    for tkey in (
                        Gst.TAG_CODEC,
                        Gst.TAG_SUBTITLE_CODEC,
                        "codec",
                    ):
                        try:
                            ok, val = tags.get_string(tkey)
                            if not ok or not val: continue
                            vl = val.lower()
                            if any(
                                t in vl
                                for t in (
                                    "ass",
                                    "ssa",
                                    "subrip",
                                    "srt",
                                    "utf8",
                                    "text",
                                )
                            ):
                                if not any(
                                    t in vl
                                    for t in ("pgs", "vobsub", "hdmv", "dvd")
                                ):
                                    is_text_sub = True
                                    break
                        except Exception:
                            continue
            except Exception: pass
        is_sub = is_text_sub or is_bitmap_sub
        if not is_sub: return
        lang = _pad_language(pad, struct)
        if not lang:
            try:
                sid = pad.get_stream_id()
            except Exception:
                sid = None
            if sid:
                lang = (getattr(app, "_custom_sub_lang_list", None) or {}).get(sid)
        lang = app._normalize_lang_code(lang) if lang else None
        sidx = len(app._custom_subtitle_pads)
        if lang:
            nice = lang
        elif is_bitmap_sub:
            nice = "Sub %d (image)" % (sidx + 1)
        else:
            nice = "Sub %d" % (sidx + 1)
        app._custom_subtitle_pads.append((pad, nice, is_text_sub))
        track = {
            "kind": "embedded",
            "index": sidx,
            "path": None,
            "label": nice,
            "text": bool(is_text_sub),
        }
        def _append_track(t=track, si=sidx):
            try:
                app.subtitle_tracks = list(app.subtitle_tracks or [])
                if not any(
                    isinstance(x, dict)
                    and x.get("kind") == "embedded"
                    and x.get("index") == si
                    for x in app.subtitle_tracks
                ):
                    app.subtitle_tracks.append(t)
                    if (
                        getattr(app, "_custom_sub_linked", False)
                        and getattr(app, "_custom_subtitle_index", -1) == si
                        and not getattr(app, "_active_external_sub_path", None)
                    ):
                        app.current_subtitle_index = len(app.subtitle_tracks) - 1
            except Exception: pass
            return False
        GLib.idle_add(_append_track)
        GLib.timeout_add(
            400, app._delayed_subtitle_lang_probe, pad, sidx
        )
        GLib.timeout_add(
            1200, app._delayed_subtitle_lang_probe, pad, sidx
        )
        return
    demux.connect("pad-added", on_pad_added)
    return pipe

def _play_file_custom_mkv(app, filename):
    app._destroy_custom_pipeline()
    try:
        app.player.set_state(Gst.State.NULL)
        app.player.get_state(Gst.SECOND)
    except Exception: pass
    try: app._apply_safe_audio_decoder_ranks()
    except Exception: pass
    if DEBUG_MYOSTOOX:
        print(
        "Myostoox: pipeline MKV custom",
        filename,
        getattr(app, "performance_mode", "?"),
        file=sys.stderr,
    )
    if app.current_is_video:
        app._ensure_video_sink_geometry()
    pipe = app._build_mkv_pipeline(filename)
    if pipe is None: return False
    app._custom_pipeline = pipe
    app._attach_custom_bus(pipe)
    if app.current_is_video:
        app._ensure_video_sink_geometry()
        try:
            sink = getattr(app, "video_sink", None)
            handle = getattr(app, "_video_window_handle", None)
            if sink is not None and handle and isinstance(sink, GstVideo.VideoOverlay):
                GstVideo.VideoOverlay.set_window_handle(sink, handle)
        except Exception: pass
    ret = pipe.set_state(Gst.State.PAUSED)
    if ret == Gst.StateChangeReturn.FAILURE:
        app._destroy_custom_pipeline()
        return False
    try: pipe.get_state(3 * Gst.SECOND)
    except Exception: pass
    if app.current_is_video:
        app._cache_video_window_handle()
        app._apply_video_overlay_handle()
        app._nudge_video_redraw()
    ret = pipe.set_state(Gst.State.PLAYING)
    if ret == Gst.StateChangeReturn.FAILURE:
        app._destroy_custom_pipeline()
        if app._effective_perf_mode() == "hardware":
            pipe2 = app._build_mkv_pipeline(filename, force_software=True)
            if pipe2 is None: return False
            app._custom_pipeline = pipe2
            app._attach_custom_bus(pipe2)
            if app.current_is_video:
                app._cache_video_window_handle()
                app._apply_video_overlay_handle()
            pipe2.set_state(Gst.State.PAUSED)
            try: pipe2.get_state(3 * Gst.SECOND)
            except Exception: pass
            if app.current_is_video:
                app._cache_video_window_handle()
                app._apply_video_overlay_handle()
            if pipe2.set_state(Gst.State.PLAYING) == Gst.StateChangeReturn.FAILURE:
                app._destroy_custom_pipeline()
                return False
            return True
        return False
    return True

