<p align="center"> <img src="https://github.com/Fraissol/Myostoox/blob/main/assets/logo_big2.png" alt="Myostoox logo" width="300"> </p> <p align="center"><br><br> <em>A complete audio player built with GTK3 and GStreamer... but a bit of a video player too.</em> <p align="center">
  <img src="https://github.com/Fraissol/Myostoox/blob/main/assets/banner.svg" alt="Myostoox — Music · Radio · IPTV · CD/DVD · Video" width="920">
</p><br> <p align="center"> <strong><a href="https://github.com/Fraissol/Myostoox/raw/refs/heads/main/myostoox_1.5-5_all.deb">📦 Download Myostoox 1.5.5 (.deb)</a></strong> </p><br> 

# Myostoox

<br>Myostoox is a versatile **audio and video player** designed primarily for GTK desktops running recent **Debian** and **Ubuntu**-based distributions, with a particular focus on **XFCE** environments such as Debian XFCE, Xubuntu, Linux Mint XFCE, MX Linux, SparkyLinux XFCE, Linux Lite, Devuan XFCE and siduction XFCE.

Free and open source, with no ads or sponsored content, Myostoox is built with Python 3, **GTK3** and **GStreamer**, and developed with the assistance of **AI**.

And it brings together music, videos, Internet radio, TV and M3U playlists, as well as optical media playback, **in a single application**.<br><br><br><br>


<p align="center">
  <img src="https://github.com/Fraissol/Myostoox/blob/main/screenshots/Player_01.jpg" alt="Playlist + EQ + Pitch/tempo + Bar color" width="700">
</p>

<br><br>
## **Features**<br>

### **Audio**

    • Local music playback

    • Internet radio

    • M3U / M3U8 / PLS playlists

    • Scrobbling — ListenBrainz / Last.fm

    • Audio CD playback

    • Audio recording of streams in MP3 format at 320kbps VBR

    • 10-Band Graphic Equalizer — Presets: Flat, Crystal, Bass Boost, Classical, Jazz, Rock-Pop …

    • Pitch and tempo control

    • Normalization (ReplayGain)

    • Crossfade / Gapless

    • Sleep timer
    
    • 3 Spectrum analyzer (Bars, Oscilloscope, Pixel)

    • LRC lyrics

    • Metadata and track information

    • Desktop notifications

### **Video**

    • Local video playback

    • Subtitles

    • Full-screen playback

    • Video playlists

    • TV / IPTV M3U playlists

    • Playback speed : 0.5x , 0.75x , 1.0x (normal) , 1.25x , 1.50x , 1.75x

    • Video playback resume support

    • Export screenshots to BMP

    • Automatic screen-blanking inhibition during playback

    • Custom handling for some MKV / E-AC3 playback cases

### **Radio, TV & playlists**

    • Internet radio stations

    • TV / IPTV bouquets

    • M3U / M3U8 / PLS import and export

    • Playlist persistence

    • Missing files are clearly identified — they appear in italics and are marked with ⚠

    • Files opened from the file manager can be sent to an already running Myostoox instance

### **Optical media**

    • Audio CDs

    • DVDs

    • Blu-rays (experimental)

### **Interface**

    • Mini-player (with scrolling banner)

    • Nano-player (with playlist)

    • Pure Spectrum mode: spectrum-only view, with size presets (Compact / Medium / Large)

    • 14 Themes

    • Hide navigation controls

    • Full-screen mode

    • Maximize mode

    • Borderless window mode 

    • Spectrum analyzer + Color choice + Spectrum synchronization

    • Transparency effect with opacity control

    • MPRIS2 integration

    • Drag-and-drop local files

    • GTK3 interface designed for lightweight Linux desktops

### **Supported Formats**

    • Audio: .mp3, .flac, .wav, .aac, .m4a, .wma, .ogg, .oga, .opus, .wv, .aif, .aiff, .dts
    
    • Video & Containers: .mp4, .mkv, .avi, .webm, .mov, .mpeg, .mpg, .ac3
    
    • Playlists & IPTV: .m3u, .m3u8, .pls
    
    • Lyrics: .lrc, .txt


### **Languages**

| | |
|---|---|
| English | Français |
| Deutsch | Castellano |
| Italiano | Nederlands |
| Português | Polski |
| Svenska | Русский |
| 简体中文 | 한국어 |
| 日本語 | |

<br>

## Screenshots

<p align="center">
  <img src="https://github.com/Fraissol/Myostoox/blob/main/screenshots/Player_02.jpg" alt="TV" width="700">
</p>

<p align="center">
  <img src="https://github.com/Fraissol/Myostoox/blob/main/screenshots/Player_14.jpg" alt="TV" width="700">
</p>

<p align="center">
  <img src="https://github.com/Fraissol/Myostoox/blob/main/screenshots/Player_03.jpg" alt="Full screen" width="700">
</p>

<p align="center">
  <img src="https://github.com/Fraissol/Myostoox/blob/main/screenshots/Player_04.jpg" alt="Themes" width="700">
</p>

<p align="center">
  <img src="https://github.com/Fraissol/Myostoox/blob/main/screenshots/Player_05.jpg" alt="Mini-player" width="700">
</p>

<p align="center">
  <img src="https://github.com/Fraissol/Myostoox/blob/main/screenshots/Player_07.jpg" alt="Bouquets" width="700">
</p>

<p align="center">
  <img src="https://github.com/Fraissol/Myostoox/blob/main/screenshots/Player_08.jpg" alt="Radios" width="700">
</p>

<p align="center">
  <img src="https://github.com/Fraissol/Myostoox/blob/main/screenshots/Player_10.jpg" alt="Lyrics" width="700">
</p>

<p align="center">
  <img src="https://github.com/Fraissol/Myostoox/blob/main/screenshots/Player_11.jpg" alt="Lyrics" width="700">
</p>

<p align="center">
  <img src="https://github.com/Fraissol/Myostoox/blob/main/screenshots/Player_09.jpg" alt="Lyrics" width="700">
</p>


<br>

## 📦 Installation

### Debian / Ubuntu / Xubuntu

Download the `.deb` package:

<p align="center">
  <strong><a href="https://github.com/Fraissol/Myostoox/raw/refs/heads/main/myostoox_1.5-5_all.deb">📦 Download Myostoox 1.5.5 (.deb)</a></strong>
</p>

From the directory containing the deb package, open a Terminal and install the application with one of the following commands:

```bash
sudo apt install ./myostoox_1.5-5_all.deb

# or

sudo dpkg -i myostoox_1.5-5_all.deb

```

### From source

Clone the repository:

```bash
git clone https://github.com/Fraissol/Myostoox.git
cd Myostoox
```

Then launch:

```bash
python3 Myostoox.py
```

Or:

```bash
chmod +x Myostoox.py
./Myostoox.py
```

## Dependencies

### Required

```bash
sudo apt update && sudo apt install -y \
  python3 python3-gi python3-gi-cairo python3-cairo \
  gir1.2-gtk-3.0 gir1.2-gst-plugins-base-1.0 gir1.2-gstreamer-1.0 \
  gir1.2-gdkpixbuf-2.0 gir1.2-pango-1.0 gir1.2-notify-0.7 \
  gstreamer1.0-tools \
  gstreamer1.0-plugins-base \
  gstreamer1.0-plugins-good \
  gstreamer1.0-plugins-bad \
  gstreamer1.0-plugins-ugly \
  gstreamer1.0-libav \
  gstreamer1.0-gl \
  gstreamer1.0-x \
  gstreamer1.0-alsa \
  gstreamer1.0-pulseaudio \
  gstreamer1.0-gtk3 \
  gstreamer1.0-vaapi \
  python3-mutagen \
  libnotify4 \
  libdvd-pkg libdvdread8t64 libdvdnav4 libbluray2 \
  ubuntu-restricted-extras
```

### Strongly recommended (Xubuntu / XFCE)

```bash
# Audio CD
sudo apt install libcdio-dev libcdio-paranoia2

# Encrypted CSS DVDs
sudo dpkg-reconfigure libdvd-pkg

# Intel GPUs
sudo apt install -y mesa-va-drivers vainfo

# NVIDIA GPUs
sudo ubuntu-drivers autoinstall
```

### Optional

```bash
# DVD / Blu-ray (depending on local legality and firmwares)
libaacs0 + KEYDB.cfg (commercial Blu-rays)
```

## Project structure

```bash
Myostoox/
├── Myostoox.py            # Entry point — GTK UI & orchestration
├── translations.json      # UI strings (13 languages)
├── logo.png
└── myostoox/              # Core library
    ├── config.py          # Paths, resume, autostart
    ├── playlist.py        # Media types, URI, JSON I/O
    ├── metadata.py        # Tags, covers, lyrics
    ├── subtitles.py       # Subtitles & audio tracks
    ├── player.py          # GStreamer / custom MKV pipeline
    └── themes.py          # Theme palettes
```

## Launching

```bash
python3 Myostoox.py
# or
chmod +x Myostoox.py
./Myostoox.py
```

Files passed as arguments (Thunar, double-click) are sent to the already running instance if one exists.

Configuration: `~/.config/Myostoox/` (playlist, state, radios, themes…).<br>


<p align="center">
  <img src="https://github.com/Fraissol/Myostoox/blob/main/screenshots/Player_06.jpg" alt="Videos" width="700">
</p>
<br>

---

## Myostoox — Keyboard Shortcuts

> All shortcuts are customizable via **Menu → Keyboard shortcuts** (saved in `state.json`).

## Playback

| Key | Action |
|---|---|
| `Space` | Play / Pause (plays the selected track if it differs from the current one) |
| `M` | Mute / Unmute |
| `Ctrl` + `↑` | Volume up (+5 %) |
| `Ctrl` + `↓` | Volume down (−5 %) |

## Seeking

| Key | Action |
|---|---|
| `←` / `→` | −5 s / +5 s |
| `J` / `L` | −10 s / +10 s |
| `Page Up` / `Page Down` | −30 s / +30 s |

## Video

| Key | Action |
|---|---|
| `F11` or `F` | Toggle fullscreen (video or lyrics) |
| `Esc` | Exit fullscreen |
| `F12` | Screenshot (video only) |

## Playlist

| Key | Action |
|---|---|
| `↑` / `↓` | Move selection up / down |
| `Shift` + `↑` / `↓` | Extend selection |
| `Delete` | Remove selected item(s) |
| `F1` | Clear playlist |
| `Ctrl` + `P` | Open playlist context menu |
| `Ctrl` + `R` | Focus the search field |
| `Ctrl` + `N` | Player hidden or shown |


## Streams

| Key | Action |
|---|---|
| `Ctrl` + `S` | Start / stop recording (radio, TV, bouquet or URL stream → MP3 320 kb/s) |

## Application

| Key | Action |
|---|---|
| `Alt` + `Q` | Quit |
| `Ctrl` + `Alt` + `X` | Quit and factory reset |

## Multimedia keys (always active, not remappable)

| Key | Action |
|---|---|
| `XF86AudioPlay` / `XF86AudioPause` | Play / Pause |
| `XF86AudioStop` | Stop |
| `XF86AudioNext` / `XF86AudioPrev` | Next / Previous track |
| `XF86AudioMute` | Mute |
| `XF86AudioRaiseVolume` / `XF86AudioLowerVolume` | Volume ±5 % |

## Notes

- While a text field has focus (e.g. the search box), single-key shortcuts are disabled so you can type freely.
  Only **Quit**, **Factory reset**, **Playlist menu**, **Focus search** and **Recording** still work there.
- Nano-player playlist: `↑` / `↓` to navigate, `Enter` to play the selected track.
- Mouse: double-click a playlist row to play it; double-click the video area to toggle fullscreen.
- Playlist multi-selection: `Ctrl` + click / `Shift` + click.
- MPRIS2 (D-Bus) is also exposed, so desktop media controls work as well.

---

## Quick troubleshooting

| Symptom | Hint |
|---------|------|
| No sound / unknown format | Install `gstreamer1.0-plugins-ugly` and `gstreamer1.0-libav` |
| Silent or crashing MKV E-AC3 | The internal custom MKV pipeline handles this case; check `gstreamer1.0-libav` |
| No notifications | `sudo apt install gir1.2-notify-0.7` |
| CD not detected | `libcdio` + ugly plugins; make sure it is a real audio CD (not data) |
| Screen turns off during a movie | Check that the session exposes the ScreenSaver D-Bus interface (XFCE does) |

---

## Platform & playback notes: Myostoox targets

**X11** desktop environments (XFCE, LXQt, and similar). Most media plays smoothly; on integrated GPUs, some heavy **4K files** may still show slight stuttering—mpv remains a stronger choice for pure high-bitrate video playback.

---

## Screen blanking / sleep under LXQt

Myostoox tries to inhibit screen blanking during **video playback** via D-Bus  
(`org.freedesktop.ScreenSaver`, then `org.freedesktop.PowerManagement.Inhibit`).

Under **LXQt** (Lubuntu), these services are often missing: this is not a playback bug.  
To prevent the screen from turning off during a movie:

1. **Settings → Power Management (LXQt)** (`lxqt-config-powermanagement`)
2. Extend or disable screen blanking / sleep
3. Optional: install a D-Bus-compatible screensaver provider

`ServiceUnknown` messages related to ScreenSaver / Notifications are silently ignored.

<br>

---

## License / usage

This project is free software distributed under the **GNU General Public License version 3** (GPL-3.0).

See the [`LICENSE`](LICENSE.txt) file for the full text.

Use in accordance with local laws (DVD/Blu-ray, stream sources).


---

##  ❤️ Inspirations

 **AIMP**<br>
 **Winamp**<br>
 **Audacious**<br>
 **DeaDBeeF**<br>
 **VLC**<br>
 **mpv**<br>
 **SMPlayer**<br>
 ...<br>


---

## Author(s)

**O. FRAISSE** & (AI) **Grok**
<br>
<p align="center">
  <img src="https://github.com/Fraissol/Myostoox/blob/main/screenshots/Player_12.jpg" alt="About" width="700">
<br></p>
<br> 

**Tip**: Transparency **+** Player hidden **+** Mini-player **→** small floating scrolling banner, movable with Alt **+** click.

<br>